@extends('layouts.admin')
@section('title','Product')
@section('content')
@endsection
